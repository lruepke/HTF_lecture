/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) YEAR OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Description
    Template for use with codeStream.

\*---------------------------------------------------------------------------*/

#include "dictionary.H"
#include "Ostream.H"
#include "Pstream.H"
#include "unitConversion.H"

//{{{ begin codeInclude
#line 24 "/Users/zguo/MyData/Research/4-Lecture/HTF_lecture/source/lectures/L_PROJECTS/cases/sill_instrusion/0/T.#codeStream"
#include "fvCFD.H"
//}}} end codeInclude

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * * Local Functions * * * * * * * * * * * * * * //

//{{{ begin localCode
#line 38 "/Users/zguo/MyData/Research/4-Lecture/HTF_lecture/source/lectures/L_PROJECTS/cases/sill_instrusion/0/T.#codeStream"
static double calTemperature(const scalar minY, const scalar maxY, const scalar minT, const scalar maxT, scalar y)
        {
            //return (minT-y*(maxT-minT)/(maxY-minY));
            return (minT - y*0.0); //put geothermal gradient here if you want one
        }
//}}} end localCode


// * * * * * * * * * * * * * * * Global Functions  * * * * * * * * * * * * * //

extern "C"
{
    void codeStream_83c5fee4f918c6b4d2f5141b70a21d2895a2fdb0
    (
        Ostream& os,
        const dictionary& dict
    )
    {
//{{{ begin code
        #line 46 "/Users/zguo/MyData/Research/4-Lecture/HTF_lecture/source/lectures/L_PROJECTS/cases/sill_instrusion/0/T.#codeStream"
const IOdictionary& d = static_cast<const IOdictionary&>(dict);
        const fvMesh& mesh = refCast<const fvMesh>(d.db());
        scalarField T(mesh.nCells(), 278.15);
        scalar minT = 278.15, maxT = 1073.15;
        vector maxC = Foam::gMax(mesh.C());
        vector minC = Foam::gMin(mesh.C());
        scalar minY = minC[1], maxY = maxC[1];

        forAll(T, i)
        {
            const scalar y = mesh.C()[i][1];
            T[i]=calTemperature(minY, maxY, minT, maxT, y);            
        }

        forAll(mesh.cellZones(), zoneI)
        {
            const cellZone& cz = mesh.cellZones()[zoneI];
            const labelList& cells = cz;

            if (cz.name() == "intrusion")
            {
                forAll(cells, iCells)
                {   
                    const label cellId = cells[iCells];
                    T[cellId] = 1273.15;
                }
            }
        }

        writeEntry(os, "", T); //
//}}} end code
    }
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //

